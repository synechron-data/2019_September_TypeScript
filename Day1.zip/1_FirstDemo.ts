class Program {
    static main(args: string): void {
        console.log("Hello, ", args);
    }

    static check(): void {
        console.log("Check Called");
    }
}

Program.main("Synechron");