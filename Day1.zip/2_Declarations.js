var data = Symbol("ABC");
var d;
