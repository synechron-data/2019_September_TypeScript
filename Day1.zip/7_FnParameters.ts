// function hello(name: string) {
//     console.log("Hello, ", name);
// }

// hello("Synechron");
// hello();                         // Error
// hello("Synechron", "Pune");      // Error

// Optional Parameters (?)
// function Add(x?: number, y?: number): number {
//     x = x || 0;
//     y = y || 0;
//     return x + y;
// }

// console.log(Add(2, 3));
// console.log(Add(2));
// console.log(Add());

// Default Parameters
function Add(x = 0, y = 0): number {
    return x + y;
}

console.log(Add(2, 3));
console.log(Add(2));
console.log(Add());
