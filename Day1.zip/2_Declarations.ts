// Implicitly Typed
// var data = 10;
// data = "ABC";

// var s = "ABC";

// var data;
// data = 10;
// data = "ABC";

// Explicitly Typed
// var age: number;
// age = "ABC";
// age = 10;

// var data;

// function add(x: number, y:number) {
//     return x + y;
// }

// add(23, 45);
// add(23, "ABC");
// add("ABC", "XYZ");

var data = Symbol("ABC");

var d: symbol;