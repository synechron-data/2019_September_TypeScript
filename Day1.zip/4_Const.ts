const env = "development";
console.log(env);

if (true) {
    const env = 10;
    console.log(env);
}

const obj = { id: 1 };

obj.id = 100;
// obj = {};