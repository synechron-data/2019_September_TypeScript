var env = "development";
console.log(env);
if (true) {
    var env_1 = 10;
    console.log(env_1);
}
var obj = { id: 1 };
obj.id = 100;
