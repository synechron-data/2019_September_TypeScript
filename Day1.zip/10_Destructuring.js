var _a;
var numArr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
var x = numArr[0], y = numArr[2];
console.log("Before Swap - x = " + x + ", y = " + y);
_a = [x, y], y = _a[0], x = _a[1];
console.log("After Swap - x = " + x + ", y = " + y);
var message1 = "Hello";
var pname = "Manish";
var message2 = "How are you?";
