// ----------------------------------------- Array Spread
// // var numArr1 = [10, 20, 30, 40, 50];
// // var numArr2 = numArr1;

// // var numArr2 = numArr1.slice();
// // var numArr2 = [...numArr1];

// // numArr2[0] = 1000;

// // console.log("1 - ", numArr1);
// // console.log("2 - ", numArr2);


// var numArr1 = [10, 20, 30];
// var numArr2 = [40, 50, 60];

// // var numArr3 = numArr1.concat(numArr2);
// var numArr3 = [...numArr1, ...numArr2];

// console.log(numArr3);

// ----------------------------------------- Object Spread

var emp1 = { id: 1, name: "Manish", address: { city: "Pune" } };

// var emp2 = emp1;
var emp2 = { ...emp1 };

emp2.id = 10;
emp2.address.city = "Mumbai";

console.log("emp1 - ", emp1);
console.log("emp2- ", emp2);