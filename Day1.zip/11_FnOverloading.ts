// function Hello() {
//     console.log("Hello World");
// }

// function Hello(name: string) {
//     console.log("Hello,", name);
// }

// Hello();
// Hello("Synechron")

// --------------------------------------
function Hello(): void;
function Hello(name: string): void;

function Hello(...args: string[]) {
    if (args.length == 0)
        console.log("Hello World");
    else
        console.log("Hello,", args[0]);
}

Hello();
Hello("Synechron");
// Hello("Synechron", "Pune");