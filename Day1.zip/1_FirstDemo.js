var Program = (function () {
    function Program() {
    }
    Program.main = function (args) {
        console.log("Hello, ", args);
    };
    Program.check = function () {
        console.log("Check Called");
    };
    return Program;
}());
Program.main("Synechron");
