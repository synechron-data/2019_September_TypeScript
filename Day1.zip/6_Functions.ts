// Fn Declaraton
// function hello(name: string) {
//     console.log("Hello, ", name);
// }

// hello("Synechron");

// Fn Expression
// function hello(name: string): string {
//     return "Hello, " + name;
// }

// var s = hello("Manish");
// console.log(s);

// var s = hello("Manish");
// console.log(s);

var d1: void;
// d1 = "ABC";
d1 = undefined;

var d2: undefined;
// d2 = 10;
d2 = undefined;

var d3: never;
// d3 = 10;
// d3 = undefined;

// Fn Expression
// const hello = function (name: string) {
//     console.log("Hello, ", name);
// }

// hello("Manish");

// ------------------------------------- IIFE

// function hello() {
//     console.log("Hello World");
// }

// hello();

// var r1 = (function () {
//     console.log("Hello World");
// })();

// var r2 = (function () {
//     throw new Error("Test");
// })();

// ------------------------------------------- Creating Functions

// var j = 10;
// console.log(j);
// console.log(typeof j);

// function add1(x: number, y: number): number {
//     return x + y;
// }

// var add2 = function (x: number, y: number): number {
//     return x + y;
// }

// // var add3: () => void;
// var add3: (a: number, b: number) => number;
// add3 = function (x: number, y: number): number {
//     return x + y;
// }

// var add4: (a: number, b: number) => number;
// add4 = function (x, y) {
//     return x + y;
// }

// var add5: (a: number, b: number) => number;
// add5 = (x, y) => {
//     return x + y;
// }

// var add6: (a: number, b: number) => number;
// add6 = (x, y) => x + y;

// // console.log(add2);
// // console.log(typeof add2);

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));
// console.log(add5(2, 3));
// console.log(add6(2, 3));

// --------------------------------------------- Use of Lambdas
// Widely used for callback implementation

var employees = [
    { id: 1, name: "ABC", city: "Pune" },
    { id: 2, name: "XYZ", city: "Mumbai" },
    { id: 3, name: "PQR", city: "Pune" }
];

// ------------------------------------
// var pune_employees = [];

// function filterFn(item: any) {
//     return item.city === "Pune"
// }

// for (let i = 0; i < employees.length; i++) {
//     if (filterFn(employees[i]))
//         pune_employees.push(employees[i]);
// }

// --------------------------------------
// function filterFn(item: any) {
//     return item.city === "Pune"
// }

// var pune_employees = employees.filter(filterFn);

// // --------------------------------------
// var pune_employees = employees.filter(function (item) {
//     return item.city === "Pune"
// });

// // --------------------------------------
// var pune_employees = employees.filter((item) => {
//     return item.city === "Pune"
// });

// --------------------------------------
var pune_employees = employees.filter((item) => item.city === "Pune");

console.log(pune_employees);