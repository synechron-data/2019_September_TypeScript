var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var e_1, _a;
var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];
try {
    for (var employees_1 = __values(employees), employees_1_1 = employees_1.next(); !employees_1_1.done; employees_1_1 = employees_1.next()) {
        var item = employees_1_1.value;
        console.log("" + item.name);
    }
}
catch (e_1_1) { e_1 = { error: e_1_1 }; }
finally {
    try {
        if (employees_1_1 && !employees_1_1.done && (_a = employees_1.return)) _a.call(employees_1);
    }
    finally { if (e_1) throw e_1.error; }
}
