// var arr1 = [10, 20, 30, 40, 50];

// var arr2: number[];
// var arr3: Array<number>;

// var arr4 = [10, 20, "ABC", true];

// var arr5: any[];
// var arr5: Array<any>;

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];

// console.log(employees.find(item => item.id === 3));

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${employees[i].name}`);
// }

// for (const key in employees) {
//     console.log(`${employees[key].name}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${item.name}`);
// });

// console.log(employees.entries());

// for (const [index, item] of employees.entries()) {
//     console.log(`${index} - ${item.name}`);
// }

for (const item of employees) {
    console.log(`${item.name}`);
}