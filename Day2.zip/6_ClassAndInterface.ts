// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// class Person implements IPerson {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }
// }

// let p1:IPerson = new Person("Abhijeet", 37);
// console.log(p1.greet("Hi"));

// let p2:IPerson = new Person("Manish", 37);
// console.log(p2.greet("Hi"));

// --------------------------------------------- Multiple Interface Implementation
// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am working...";
//     }
// }

// let p1: Person = new Person("Abhijeet", 37);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// // --------------------------------------------- Interface can extend other Interface
// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): void;
// }

// class Person implements ICustomer, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doShopping():void{
//         console.log("Let's go to the mall");
//     }

//     doWork(): string {
//         return "I am working...";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 37);
// // console.log(p1.greet("Hi"));
// // p1.doShopping();
// // console.log(p1.doWork());

// // let p1: IPerson = new Person("Abhijeet", 37);

// // let p1: ICustomer = new Person("Abhijeet", 37);

// // let p1: IWork = new Person("Abhijeet", 37);

// ------------------------------------------------- Interface can extend from class

// class Vehicle {
//     constructor(public make: string) { }

//     getMake() {
//         return this.make;
//     }
// }

// class Engine {
//     constructor(public manufacturer: string) { }

//     getManufacturer() {
//         return this.manufacturer;
//     }
// }

// interface IFourWheeler extends Vehicle, Engine {}

// class FourWheeler implements IFourWheeler {
//     public make: string;
//     public manufacturer: string;

//     getMake(): string {
//         throw new Error("Method not implemented.");
//     }    
    
//     getManufacturer(): string {
//         throw new Error("Method not implemented.");
//     }
// }