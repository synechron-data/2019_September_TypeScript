// class Employee {
//     private _name: string;

//     // Multiple constructor implementations are not allowed.
//     // constructor(){
//     //     this._name = "NA";
//     // }

//     // constructor(name){
//     //     this._name = name;
//     // }

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     // Donot use Lambda as Class Member (Increases Memory Usage)
//     // getName = () => this._name;

//     setName(name: string) {
//         this._name = name;
//     }
// }

// var e1 = new Employee();
// console.log(e1.getName());
// e1.setName("Manish");
// console.log(e1.getName());

// var e2 = new Employee("Subodh");
// console.log(e2.getName());
// e2.setName("Abhijeet");
// console.log(e2.getName());

// --------------------------------------------- Properties
// Properties enable developers to expose private class members and 
// to encapsulate the logic of getting or setting that member. 

// class Employee {
//     private _name: string;

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }
// }

// var e1 = new Employee();
// console.log(e1.Name);
// e1.Name = "Manish";
// console.log(e1.Name);

// ----------------------------------- Parameter Properties/Members
// Parameter properties let us create and initialize member variables in one place. 
// It is a shorthand for creating member variables.

// class Employee {
//     constructor(private _name = "NA", private _age = 0) { }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(age: number) {
//         this._age = age;
//     }
// }

// var e1 = new Employee();
// console.log(e1.Name);
// e1.Name = "Manish";
// console.log(e1.Name);

// ----------------------------------------------- Static Members

// class BankAccount {
//     constructor(private _bankname: string, private _accname: string) { }

//     get BankName(): string {
//         return this._bankname;
//     }

//     get AccountName(): string {
//         return this._accname;
//     }
// }

// var a1 = new BankAccount("ICICI", "Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("ICICI", "Abhijeet");
// console.log("Bank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// class BankAccount {
//     private static _bankname: string = "HDFC";

//     constructor(private _accname: string) { }

//     static set BankName(bankname: string) {
//         BankAccount._bankname = bankname;
//     }

//     get BankName(): string {
//         return BankAccount._bankname;
//     }

//     get AccountName(): string {
//         return this._accname;
//     }
// }

// BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("Bank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// ------------------------------------------------------- Readonly Members

class BankAccount {
    private static _bankname: string = "HDFC";

    constructor(private readonly _accNumber: number, private _accname: string) { }

    static set BankName(bankname: string) {
        BankAccount._bankname = bankname;
    }

    get AccountNumber(): number {
        // this._accNumber = 100;
        return this._accNumber;
    }

    get BankName(): string {
        return BankAccount._bankname;
    }

    get AccountName(): string {
        return this._accname;
    }
}

BankAccount.BankName = "ICICI";

var a1 = new BankAccount(1, "Manish");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);

var a2 = new BankAccount(2, "Abhijeet");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);
