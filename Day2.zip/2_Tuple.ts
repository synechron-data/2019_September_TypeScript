// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr: number[] = [10, 20, 30];

// var arr: (string | number)[] = ["Manish", 1];
// arr = ["Manish", "Sharma"];
// arr = [10, 20];
// arr = [10, "ABC"];
// arr = [10, "ABC", 20];

// Tuple
var dataRow: [number, string] = [1, "ABC"];
// dataRow = ["ABC", "XYZ"];
// dataRow = [10, 20];
// dataRow = ["Manish", 1];
// dataRow = [10, "ABC", 20];

for (const item of dataRow) {
    console.log(item);
}

